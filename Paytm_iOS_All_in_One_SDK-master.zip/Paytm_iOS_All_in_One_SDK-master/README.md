# Paytm All-in-One SDK for iOS
* More Details: **https://developer.paytm.com/docs/all-in-one-sdk/#ios**

## Paytm Staging App
* App Link: https://testflight.apple.com/join/oeXnj05q

Select Staging API for GTM
1. Go to side menu -> scroll down -> Debub Setting -> Change Debug Link
2. change the three mentioned host's URLs as follows.
2. Change the three mentioned host's URLs as follows.

older link: https://accounts-staging.paytm.in

new link:  https://accounts-uat.paytm.com

older link: https://securegw-staging.paytm.in

new link:  https://securegw-stage.paytm.in

older link - https://pgp-staging.paytm.in 

new link - https://securegw-stage.paytm.in

kill the app and run again.




